﻿namespace Splatoon.Structures;

public class SearchInfo
{
    public string name = "";
    public uint oid;
    public int SearchAttribute = 0;
    public bool includeUntargetable = false;
}
