Will make aether currents detectable from further distances and behind objects
```
aether current~{"ZoneLockH":[],"Elements":{"1":{"type":1,"refX":475.37823,"refY":736.0456,"refZ":212.53989,"overlayBGColor":1879048447,"thicc":5.0,"overlayText":"aether current","refActorName":"aether current","includeHitbox":true,"onlyTargetable":true,"tether":true}},"DisableInDuty":true,"Triggers":[],"MaxDistance":87.1,"DistanceLimitType":1}
```
