Rank SS minion: Ker shroud: Entrophic flame cast telegraph
```
Ker shroud - Entropic Flame~{"ZoneLockH":[958,956,957,959,960,961],"DCond":5,"Elements":{"Cast":{"type":3,"refY":50.0,"radius":1.2,"color":1728053503,"refActorName":"Ker shroud","includeHitbox":true,"includeRotation":true,"onlyTargetable":true}},"UseTriggers":true,"Triggers":[{"Type":2,"Duration":4,"Match":"The Ker shroud begins casting Entropic Flame."}]}
```
