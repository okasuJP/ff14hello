Some presets were made by:
- [Errerer](https://github.com/Errerer/)
- [Exnter](https://github.com/Exnter/) 
- [LAMMY](https://github.com/LAMMY-33)
