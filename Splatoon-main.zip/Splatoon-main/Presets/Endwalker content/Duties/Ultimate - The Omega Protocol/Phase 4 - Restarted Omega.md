[International] Wave repeater
- Import from phase 3 page: https://github.com/PunishXIV/Splatoon/blob/main/Presets/Endwalker%20content/Duties/Ultimate%20-%20The%20Omega%20Protocol/Phase%203%20-%20Final%20omega.md#intermission

[International] Wave cannon snapshot lines
```
~Lv2~{"Name":"P4 Wave Cannon","Group":"TOP","ZoneLockH":[1122],"ElementsL":[{"Name":"Snapshot","type":3,"refY":20.0,"radius":3.0,"color":1191182080,"refActorNPCNameID":7636,"refActorRequireCast":true,"refActorCastId":[31616],"refActorComparisonType":6,"includeRotation":true},{"Name":"Target you (1st)","type":3,"refY":20.0,"radius":3.0,"color":1174405375,"refActorNPCNameID":7636,"refActorRequireCast":true,"refActorCastId":[31617],"refActorComparisonType":6,"includeRotation":true,"FaceMe":true}]}
```
