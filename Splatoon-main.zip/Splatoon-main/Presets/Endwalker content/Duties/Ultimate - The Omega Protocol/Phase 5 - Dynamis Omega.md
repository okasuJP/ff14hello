# Common
[Script] [International] Hello Near/Far World verification. Will show where hits will land, as well as their path and radius.
```
https://github.com/PunishXIV/Splatoon/raw/main/SplatoonScripts/Duties/Endwalker/The%20Omega%20Protocol/Hello%20Near%20Far%20World.cs
```

# Delta
https://github.com/PunishXIV/Splatoon/blob/main/Presets/Endwalker%20content/Duties/Ultimate%20-%20The%20Omega%20Protocol/Phase%205%20-%20Dynamis%20Omega%20-%201.%20Delta.md

# Sigma
https://github.com/PunishXIV/Splatoon/blob/main/Presets/Endwalker%20content/Duties/Ultimate%20-%20The%20Omega%20Protocol/Phase%205%20-%20Dynamis%20Omega%20-%202.%20Sigma.md

# Omega
https://github.com/PunishXIV/Splatoon/blob/main/Presets/Endwalker%20content/Duties/Ultimate%20-%20The%20Omega%20Protocol/Phase%205%20-%20Dynamis%20Omega%20-%203.%20Omega.md

