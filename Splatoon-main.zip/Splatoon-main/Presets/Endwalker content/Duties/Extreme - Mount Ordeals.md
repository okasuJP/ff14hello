[International] [Untested] Spread (4/4) / 分組分散
```
~Lv2~{"Name":"Spread (4/4) / 分組分散","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32002 - 重畳警察","type":1,"radius":5.0,"color":3355508706,"overlayBGColor":2483027968,"overlayTextColor":4280024832,"overlayVOffset":2.0,"thicc":4.0,"overlayText":"<<< SPREAD >>>","refActorPlaceholder":["<t1>","<t2>","<h2>","<d1>","<d2>","<d3>","<d4>","<h1>"],"refActorUseBuffTime":true,"refActorBuffTimeMax":6.0,"refActorComparisonType":5,"onlyTargetable":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":4.7,"Match":"(12054>32002)"}],"MaxDistance":5.0,"UseDistanceLimit":true,"DistanceLimitType":1}
```

[International] [Untested] Triangular Spread / 分散火流
```
~Lv2~{"Name":"Triangular Spread / 分散火流","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"31998 - 三角区","type":4,"radius":50.0,"coneAngleMin":-15,"coneAngleMax":15,"color":3355508706,"overlayBGColor":2483027968,"overlayTextColor":4280024832,"overlayVOffset":2.0,"thicc":4.0,"refActorModelID":3729,"FillStep":1.0,"refActorComparisonType":1,"includeRotation":true,"onlyVisible":true,"Filled":true,"FaceMe":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":6.0,"Match":"(12054>31998)","MatchDelay":2.0}]}
```

[International] [Untested] Tornado Spread / 火燕流（分散）
```
~Lv2~{"Name":"Tornado Spread / 火燕流（分散）","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32015 - 重畳警察","type":1,"radius":5.0,"color":3355508706,"overlayBGColor":2483027968,"overlayTextColor":4280024832,"overlayVOffset":2.0,"thicc":4.0,"overlayText":"<<< SPREAD >>>","refActorPlaceholder":["<t1>","<t2>","<h2>","<d1>","<d2>","<d3>","<d4>","<h1>"],"refActorUseBuffTime":true,"refActorBuffTimeMax":6.0,"refActorComparisonType":5,"onlyTargetable":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":8.0,"Match":"(12054>32015)"}]}
```

[International] [Untested] Charge Line/ 分身直綫
```
~Lv2~{"Name":"Charge Line/ 分身直綫","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"ElementsL":[{"Name":"12057 - 雜魚直綫","type":3,"refY":60.0,"radius":3.01,"color":1022622098,"thicc":1.0,"refActorNPCNameID":12057,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true,"Filled":true}]}
```

[International] [Untested] 1/2AOE / 面向順劈
```
~Lv2~{"Name":"1/2AOE / 面向順劈","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32033 - 半場順劈","type":4,"radius":20.0,"coneAngleMin":-90,"coneAngleMax":90,"color":3355508706,"overlayBGColor":2483027968,"overlayTextColor":4280024832,"overlayVOffset":2.0,"thicc":4.0,"refActorNPCNameID":12054,"FillStep":2.0,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true,"Filled":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":8.0,"Match":"(12054>32033)"}]}
```

[International] [Untested] Dice / 麻将点名
```
~Lv2~{"Name":"Dice / 麻将点名","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"ElementsL":[{"Name":"1","type":1,"radius":0.0,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4294311819,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 1 ","refActorComparisonType":7,"onlyVisible":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a1t.avfx","refActorVFXMax":30000},{"Name":"2","type":1,"radius":0.0,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4278255601,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 2 ","refActorComparisonType":7,"onlyVisible":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a2t.avfx","refActorVFXMax":30000},{"Name":"3","type":1,"radius":0.56,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4294311819,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 3 ","refActorComparisonType":7,"onlyVisible":true,"Filled":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a3t.avfx","refActorVFXMax":30000},{"Name":"4","type":1,"radius":0.56,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4278255601,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 4 ","refActorComparisonType":7,"onlyVisible":true,"Filled":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a4t.avfx","refActorVFXMax":30000},{"Name":"5","type":1,"radius":0.56,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4294311819,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 5 ","refActorComparisonType":7,"onlyVisible":true,"Filled":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a5t.avfx","refActorVFXMax":30000},{"Name":"6","type":1,"radius":0.56,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4278255601,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 6 ","refActorComparisonType":7,"onlyVisible":true,"Filled":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a6t.avfx","refActorVFXMax":30000},{"Name":"7","type":1,"radius":0.56,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4294311819,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 7 ","refActorComparisonType":7,"onlyVisible":true,"Filled":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a7t.avfx","refActorVFXMax":30000},{"Name":"8","type":1,"radius":0.56,"color":3371299322,"overlayBGColor":3137339392,"overlayTextColor":4278255601,"overlayVOffset":2.0,"overlayFScale":2.0,"thicc":0.0,"overlayText":" 8 ","refActorComparisonType":7,"onlyVisible":true,"Filled":true,"refActorVFXPath":"vfx/lockon/eff/m0361trg_a8t.avfx","refActorVFXMax":30000}]}
```

[International] [Untested] Fire Stack / 重炎分攤
```
~Lv2~{"Name":"Fire Stack / 重炎分攤","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32035 - 分攤","type":1,"radius":4.0,"color":3355508706,"overlayBGColor":2483027968,"overlayTextColor":4278216703,"overlayVOffset":2.0,"thicc":4.0,"overlayText":">>> STACK<<<","refActorPlaceholder":["<t1>","<t2>","<h2>","<d1>","<d2>","<d3>","<d4>","<h1>"],"refActorUseBuffTime":true,"refActorBuffTimeMax":6.0,"refActorComparisonType":5,"refActorType":1,"onlyTargetable":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":7.2,"Match":"(12054>32035)"}]}
```

[International] [Untested] Fire Spread  / 重炎分散
```
~Lv2~{"Name":"Fire Spread  / 重炎分散","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32034 - 重畳警察","type":1,"radius":5.0,"color":3355508706,"overlayBGColor":2483027968,"overlayTextColor":4280024832,"overlayVOffset":2.0,"thicc":4.0,"overlayText":"<<< SPREAD >>>","refActorPlaceholder":["<t1>","<t2>","<h2>","<d1>","<d2>","<d3>","<d4>","<h1>"],"refActorUseBuffTime":true,"refActorBuffTimeMax":6.0,"refActorComparisonType":5,"onlyTargetable":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":7.2,"Match":"(12054>32034)"}],"MaxDistance":5.0,"UseDistanceLimit":true,"DistanceLimitType":1}
```

[International] [Untested] Wheels Fire / 烽火
```
~Lv2~{"Name":"Wheels Fire / 烽火","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32036 - 鋼鉄","type":4,"radius":10.0,"coneAngleMin":-270,"coneAngleMax":90,"color":2113994724,"overlayBGColor":2483027968,"overlayTextColor":4280024832,"overlayVOffset":2.0,"thicc":4.0,"refActorNPCNameID":12054,"FillStep":1.798,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true,"Filled":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":4.7,"Match":"(12054>32036)"}]}
```

[International] [Untested] Donuts Fire / 環火
```
~Lv2~{"Name":"Donuts Fire / 環火","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"32036 - 月環","type":1,"radius":10.0,"color":4278255588,"overlayBGColor":3355443200,"overlayTextColor":4280024832,"overlayVOffset":2.0,"overlayFScale":3.0,"thicc":5.0,"overlayText":" > > IN < < ","refActorNPCNameID":12054,"FillStep":1.798,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":4.7,"Match":"(12054>32037)"}]}
```

[International] [Untested] Tilt Cross:
```
~Lv2~{"Name":"Tilt Cross one/ X字 1","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"1","type":2,"refX":115.0,"refY":115.0,"offX":85.849945,"offY":85.0,"offZ":3.8146973E-06,"radius":5.93,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true,"AdditionalRotation":1.5707964},{"Name":"2","type":2,"refX":85.0,"refY":115.0,"offX":115.0,"offY":85.0,"offZ":3.8146973E-06,"radius":6.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":8.0,"Match":"MapEffect: 4, 16, 16"}]}
```
```
~Lv2~{"Name":"Tilt Cross two/ X字 2","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"2","type":2,"refX":104.54103,"refY":119.37592,"refZ":-3.8146973E-06,"offX":80.634834,"offY":95.22506,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"1","type":2,"refX":119.502686,"refY":104.104996,"refZ":3.8146973E-06,"offX":95.05059,"offY":80.65218,"offZ":3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true,"AdditionalRotation":1.5707964},{"Name":"3","type":2,"refX":95.13661,"refY":119.374916,"refZ":-3.8146973E-06,"offX":119.40933,"offY":95.352615,"radius":4.0,"color":1444410872},{"Name":"4","type":2,"refX":104.59005,"refY":80.56987,"offX":80.57464,"offY":104.32157,"offZ":-3.8146973E-06,"radius":4.0,"color":1444410872}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":2.0,"Match":"MapEffect: 4, 16, 16","MatchDelay":8.0}]}
```
```
~Lv2~{"Name":"Tilt Cross three/ X字 3","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"2","type":2,"refX":105.834,"refY":131.132,"offX":74.621,"offY":101.333,"offZ":3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"1","type":2,"refX":100.0,"refY":74.192,"offX":66.97,"offY":107.52,"offZ":3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"3","type":2,"refX":126.434,"refY":99.94,"offX":88.241,"offY":63.18,"offZ":3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"4","type":2,"refX":128.8,"refY":96.152,"offX":95.86,"offY":130.931,"offZ":-3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":2.0,"Match":"MapEffect: 4, 16, 16","MatchDelay":10.0}]}
```

[International] [Untested] Vertical Cross:
```
~Lv2~{"Name":"Vertical Cross  one/ 十字1","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"1","type":2,"refX":100.112045,"refY":80.0099,"offX":100.06953,"offY":119.992714,"radius":6.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true,"AdditionalRotation":1.5707964},{"Name":"2","type":2,"refX":119.98272,"refY":99.91692,"offX":80.0,"offY":100.0,"radius":6.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":8.0,"Match":"MapEffect: 4, 512, 512"}]}
```
```
~Lv2~{"Name":"Vertical Cross  two/ 十字2","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"2","type":2,"refX":117.0078,"refY":110.46602,"refZ":3.8146973E-06,"offX":82.94831,"offY":110.35787,"offZ":-3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"1","type":2,"refX":89.410545,"refY":83.09251,"offX":89.73648,"offY":117.130356,"offZ":-3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"3","type":2,"refX":116.94455,"refY":89.8325,"offX":82.902435,"offY":89.71555,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"4","type":2,"refX":110.267494,"refY":117.10025,"offX":109.99691,"offY":82.67847,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":2.0,"Match":"MapEffect: 4, 512, 512","MatchDelay":8.0}]}
```
```
~Lv2~{"Name":"Vertical Cross three/ 十字3","Group":"Rubicante - Ex / 盧比坎特 - 極","ZoneLockH":[1096],"DCond":5,"ElementsL":[{"Name":"2","type":2,"refX":121.334,"refY":118.612,"offX":74.621,"offY":118.373,"offZ":3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"1","type":2,"refX":81.818,"refY":75.972,"offX":81.553,"offY":124.091,"offZ":-3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"3","type":2,"refX":121.274,"refY":82.0,"offX":74.281,"offY":82.0,"offZ":3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true},{"Name":"4","type":2,"refX":118.0,"refY":75.692,"offX":118.0,"offY":124.091,"offZ":-3.8146973E-06,"radius":4.0,"color":1444410872,"refActorNPCNameID":12054,"refActorComparisonType":6,"includeRotation":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":2.0,"Match":"MapEffect: 4, 512, 512","MatchDelay":10.0}]}
```

### Presets made by
[Errerer](https://github.com/Errerer/) and [Exnter](https://github.com/Exnter/) 
