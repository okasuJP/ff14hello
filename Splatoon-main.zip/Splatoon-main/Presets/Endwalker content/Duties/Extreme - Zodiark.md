Marks a 5yalm ring around the adds in Zodiark so that you can find the aoe sweet spot to hit all 4 adds easily
```
Zodiark aoe~{"ZoneLockH":[993],"Elements":{"Roiling Darkness":{"type":1,"refX":-603.3536,"refY":-842.1655,"refZ":30.019999,"radius":5.0,"refActorName":"Roiling Darkness","includeHitbox":true}},"Triggers":[]}
```
Shows the green laser divider (accurate) - Adikia hitbox (accurate) - snake rows (not 100% accurate since they change depending how they rotate) - Diagonals (not sure about the width for the fire)
```
Zodiark laser/adikia/snake~{"ZoneLockH":[993],"Elements":{"divider1":{"type":2,"refX":79.0,"refY":89.2,"offX":121.0,"offY":89.2,"radius":0.0,"color":3372154880,"overlayText":"divider1"},"divider2":{"type":2,"refX":79.0,"refY":100.0,"offX":121.0,"offY":100.0,"radius":0.0,"color":3372154880,"overlayText":"divider2"},"divider3":{"type":2,"refX":79.0,"refY":110.8,"offX":121.0,"offY":110.8,"radius":0.0,"color":3372154880,"overlayText":"divider3"},"diagonal1":{"type":2,"refX":79.0,"refY":79.0,"offX":121.0,"offY":121.0,"radius":0.0,"color":3355467481},"diagonal2":{"type":2,"refX":79.0,"refY":121.0,"offX":121.0,"offY":79.0,"radius":0.0,"color":3355467481},"third1":{"type":2,"refX":93.0,"refY":79.0,"offX":93.0,"offY":121.0,"radius":0.0,"color":3355508480},"third2":{"type":2,"refX":107.0,"refY":79.0,"offX":107.0,"offY":121.0,"radius":0.0,"color":3355508480},"divider4":{"type":2,"refX":89.2,"refY":79.0,"offX":89.2,"offY":121.0,"radius":0.0,"color":3372154880},"divider5":{"type":2,"refX":100.0,"refY":79.0,"offX":100.0,"offY":121.0,"radius":0.0,"color":3372154880},"divider6":{"type":2,"refX":110.8,"refY":79.0,"offX":110.8,"offY":121.0,"radius":0.0,"color":3372154880},"Adikia1":{"refX":79.0,"refY":100.0,"radius":21.0},"Adikia2":{"refX":121.0,"refY":100.0,"radius":21.0}},"Triggers":[]}
```
Algedon marker (accurate)
```
Zodiark-Algedon~{"ZoneLockH":[993],"Elements":{"Algedon1":{"type":2,"refX":79.0,"refY":99.8,"offX":99.8,"offY":79.0,"radius":0.0},"Algedon2":{"type":2,"refX":100.2,"refY":79.0,"offX":121.0,"offY":99.8,"radius":0.0},"Algedon3":{"type":2,"refX":121.0,"refY":100.2,"offX":100.2,"offY":121.0,"radius":0.0},"Algedon4":{"type":2,"refX":99.8,"refY":121.0,"offX":79.0,"offY":100.2,"radius":0.0}},"Triggers":[]}
```
