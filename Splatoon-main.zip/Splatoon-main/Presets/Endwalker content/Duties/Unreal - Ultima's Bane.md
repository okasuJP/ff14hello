Garuda cleave
```
Ultima Unreal - Garuda~{"ZoneLockH":[1035],"DCond":5,"Elements":{"Garuda":{"type":4,"refX":-21.39305,"refY":2.287123,"refZ":211.0,"radius":20.0,"coneAngleMin":-75,"coneAngleMax":75,"color":4294963968,"refActorName":"Ultima Garuda","includeRotation":true,"onlyUnTargetable":true,"onlyVisible":true,"Filled":true}},"UseTriggers":true,"Triggers":[{"Duration":50.0}]}
```

Ifrit dash
```
Ultima Unreal - Ifrit~{"ZoneLockH":[1035],"Elements":{"Ifrit":{"type":3,"refY":40.0,"radius":0.0,"color":2516582655,"refActorName":"Ultima Ifrit","includeHitbox":true,"includeRotation":true,"onlyVisible":true}}}
```
