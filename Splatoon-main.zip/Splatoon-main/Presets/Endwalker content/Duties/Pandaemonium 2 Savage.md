Divebomb arena divider, helps to see safe/unsafe zone exacrly. Includes trigger to show only when necessary.
```
p2s divebomb divider~{"ZoneLockH":[1005],"DCond":5,"Elements":{"divider":{"type":2,"refX":100.0,"refY":124.452,"refZ":-1.9073486E-06,"offX":100.0,"offY":75.88,"radius":0.0}},"UseTriggers":true,"Triggers":[{"TimeBegin":370,"Duration":60},{"TimeBegin":535,"Duration":30}]}
```
Limit Cut: Will roughly show where to stand on the platform for the 1+3 and 2+4 Blue markers in front and back of boss
```
P2S Limit Cut~{"ZoneLockH":[1005],"Elements":{"Back 1":{"type":1,"refX":99.343056,"refY":120.81869,"offY":-25.0,"overlayText":"1","refActorName":"Hippokampos","includeRotation":true,"onlyTargetable":true,"onlyVisible":true},"Back 3":{"type":1,"refX":99.933,"refY":119.5571,"refZ":4.3899297E-11,"offY":-27.02,"overlayText":"3","refActorName":"Hippokampos","includeRotation":true,"onlyTargetable":true,"onlyVisible":true},"Front 2":{"type":1,"refX":96.70545,"refY":120.96481,"offY":3.0,"overlayText":"2","refActorName":"Hippokampos","includeRotation":true,"onlyTargetable":true,"onlyVisible":true},"Front 4":{"type":1,"refX":96.70545,"refY":120.96481,"offY":5.0,"overlayText":"4","refActorName":"Hippokampos","includeRotation":true,"onlyTargetable":true,"onlyVisible":true}},"Triggers":[]}
```
