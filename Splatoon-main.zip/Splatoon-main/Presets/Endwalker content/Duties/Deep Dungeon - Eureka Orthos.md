```
~Lv2~{"Name":"Fitter","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Unholy","type":1,"radius":0.0,"Donut":30.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12227,"refActorRequireCast":true,"refActorCastId":[2319,2362,3978,32931],"FillStep":0.3,"refActorComparisonType":6,"tether":true}]}
```
```
~Lv2~{"Name":"Zaghnal","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Beastly Roar","type":1,"radius":0.0,"Donut":30.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12230,"refActorRequireCast":true,"refActorCastId":[15716,32937],"FillStep":0.3,"refActorComparisonType":6,"tether":true}]}
```
```
~Lv2~{"Name":"Orthonaught","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1124,1108,1107,1106,1105],"ElementsL":[{"Name":"Rotoswipe","type":4,"radius":5.0,"coneAngleMin":-50,"coneAngleMax":50,"refActorNPCNameID":12226,"refActorRequireCast":true,"refActorCastId":[1238,1492,2003,2553,3030,4556,12945,15302,15303,32893],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Sphinx","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Swinge","type":4,"radius":15.0,"coneAngleMin":-35,"coneAngleMax":35,"refActorNPCNameID":12228,"refActorRequireCast":true,"refActorCastId":[903,2295,2727,3455,4367,8906,11725,32421,32913],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Mithridates","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Laserblade","type":4,"radius":15.0,"coneAngleMin":-135,"coneAngleMax":135,"refActorNPCNameID":12225,"refActorRequireCast":true,"refActorCastId":[15851,15852,32880],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Chimera 2","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Dragon","type":1,"radius":7.0,"Donut":10.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12233,"refActorRequireCast":true,"refActorCastId":[1105,1338,1442,2145,2604,3344,7079,10965,11420,12432,13192,13395,14764,15080,16963,21580,31853,32444,32806,32910],"FillStep":0.3,"refActorComparisonType":6},{"Name":"Ice","type":1,"radius":10.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12233,"refActorRequireCast":true,"refActorCastId":[1104,1285,2144,2603,3343,7078,11419,12431,13191,13394,14763,15079,16962,21579,31854,32443,32807,32909],"refActorComparisonType":6,"Filled":true},{"Name":"Dragon 2","type":4,"radius":15.0,"coneAngleMin":-110,"coneAngleMax":20,"refActorNPCNameID":12233,"refActorRequireCast":true,"refActorCastId":[446,1103,1337,3441,4651,4673,6999,10044,11839,11953,12435,13195,16959,20543,20544,20545,27588,32907],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Ice 2","type":4,"radius":15.0,"coneAngleMin":-20,"coneAngleMax":110,"refActorNPCNameID":12233,"refActorRequireCast":true,"refActorCastId":[32906],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Tail","type":4,"radius":5.0,"coneAngleMin":-55,"coneAngleMax":55,"refActorNPCNameID":12233,"refActorRequireCast":true,"refActorCastId":[1282,13393,16961,32908],"refActorComparisonType":6,"includeRotation":true,"AdditionalRotation":3.1415927,"Filled":true}]}
```
```
~Lv2~{"Name":"Orthotaur 2","Group":"Deep Dungeon","ZoneLockH":[156,1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Swipe","type":4,"radius":25.0,"coneAngleMin":-30,"coneAngleMax":30,"refActorNPCNameID":12234,"refActorRequireCast":true,"refActorCastId":[12293,15803,32921],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Swing","type":1,"radius":12.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12234,"refActorRequireCast":true,"refActorCastId":[10980,12291,15802,32922],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Citadel Buster","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Citadel Buster","type":3,"refY":25.0,"radius":0.25,"refActorNPCNameID":12232,"refActorRequireCast":true,"refActorCastId":[6554,6935,7579,7595,10130,10149,29020,32900],"refActorComparisonType":6,"includeHitbox":true,"includeRotation":true}]}
```
```
~Lv2~{"Name":"Orthodrone","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Self Destruct","type":1,"radius":5.0,"color":1677721855,"overlayBGColor":4278190080,"overlayTextColor":4294967295,"thicc":3.0,"overlayText":"RUN","refActorNPCNameID":12223,"refActorRequireCast":true,"refActorCastId":[337,677,678,1680,1684,1693,1789,2426,2631,4811,5330,5337,5340,6289,6984,7106,10747,11408,12234,12235,14687,14688,14730,15570,16260,16263,17213,18725,20334,21489,22951,22952,23500,23501,25644,25647,26991,26992,28564,28565,28726],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"System A","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Aetherochemical Laser","type":4,"radius":10.0,"coneAngleMin":-55,"coneAngleMax":55,"refActorNPCNameID":12229,"refActorRequireCast":true,"refActorCastId":[3943,4321,6030,6549,6550,6551,7574,7575,7576,10147,10154,11140,11141,11142,12395,23716,23717,32416],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"System Y","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"High Voltage","type":1,"radius":25.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12224,"refActorRequireCast":true,"refActorCastId":[1216,1447,8682,11387,14890,32878],"refActorComparisonType":6,"Filled":true},{"Name":"Repelling Cannons","type":1,"radius":8.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12224,"refActorRequireCast":true,"refActorCastId":[1217,1448,2947,3312,14892,32877],"refActorComparisonType":6,"Filled":true},{"Name":"Ring Cannon","type":1,"radius":3.5,"Donut":10.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12224,"refActorRequireCast":true,"refActorCastId":[32876],"FillStep":0.3,"refActorComparisonType":6}]}
```
```
~Lv2~{"Name":"Aetherochemical Cannon","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1103,1102,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Aetherochemical Cannon","type":4,"radius":10.0,"coneAngleMin":-90,"coneAngleMax":90,"refActorNPCNameID":12231,"refActorRequireCast":true,"refActorCastId":[33200],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Nicker","Group":"Deep Dungeon","ZoneLockH":[341,1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Nicker","type":1,"radius":12.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12219,"refActorRequireCast":true,"refActorCastId":[7757,12307,18071,21668,26781,28772,32768],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Scream","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Scream","type":1,"radius":21.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12220,"refActorRequireCast":true,"refActorCastId":[594,6410,6433,7145,9531,12195,32772],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Specter","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Left Sweep","type":4,"radius":8.0,"coneAngleMin":-180,"coneAngleMax":30,"refActorNPCNameID":12221,"refActorRequireCast":true,"refActorCastId":[31076,31100,32776],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Right Sweep","type":4,"radius":8.0,"coneAngleMin":-30,"coneAngleMax":180,"refActorNPCNameID":12221,"refActorRequireCast":true,"refActorCastId":[31075,31099,32777],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Ringing Burst","type":1,"radius":3.82,"Donut":5.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12221,"refActorRequireCast":true,"refActorCastId":[32775],"FillStep":0.3,"refActorComparisonType":6},{"Name":"Surrounding Burst","type":1,"radius":15.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12221,"refActorRequireCast":true,"refActorCastId":[32774],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Triple Trial","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Triple Trial","type":4,"radius":8.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12211,"refActorRequireCast":true,"refActorCastId":[5478,5850,5987,30355,32740],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Demon Eye","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Demon Eye","type":1,"radius":0.1,"Donut":30.0,"thicc":3.0,"refActorNPCNameID":12218,"refActorRequireCast":true,"refActorCastId":[2099,9485,9494,14691,20961,32761,32762],"FillStep":5.0,"refActorComparisonType":6,"tether":true}]}
```
```
~Lv2~{"Name":"Glass Punch","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Glass Punch","type":4,"radius":7.0,"coneAngleMin":-60,"coneAngleMax":60,"refActorNPCNameID":12217,"refActorRequireCast":true,"refActorCastId":[6877,6904,9536,10613,11912,19063,32399,32759],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Blistering Roar","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Blistering Roar","type":3,"refY":22.0,"radius":8.0,"refActorNPCNameID":12208,"refActorRequireCast":true,"refActorCastId":[15010,33199],"FillStep":1.0,"refActorComparisonType":6,"includeRotation":true},{"Name":"Blistering Roar LoS","type":1,"radius":0.0,"color":255,"overlayBGColor":4278190080,"overlayTextColor":4294967295,"overlayVOffset":1.5,"overlayText":"NO LoS","refActorNPCNameID":12208,"refActorRequireCast":true,"refActorCastId":[15010,33199],"refActorComparisonType":6}]}
```
```
~Lv2~{"Name":"Chirp","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Chirp","type":1,"radius":5.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12198,"refActorRequireCast":true,"refActorCastId":[4523,4955,6365,10584,13310,14000,15377,16210,18301,32637],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Thunderbeast","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Spark","type":1,"radius":7.0,"Donut":10.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12207,"refActorRequireCast":true,"refActorCastId":[3432,3433,7663,7664,9565,10598,13431,14836,14837,27221,32216,32660],"FillStep":0.3,"refActorComparisonType":6},{"Name":"Scythe Tail","type":1,"radius":5.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12207,"refActorRequireCast":true,"refActorCastId":[7697,8190,8407,8738,10760,14021,21344,26725,27222,28243,32428,32656],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Basilisk","Group":"Deep Dungeon","ZoneLockH":[156],"ElementsL":[{"Name":"Stone Gaze","type":4,"radius":10.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12190,"refActorRequireCast":true,"refActorCastId":[410,499,1161,2734,5140,6351,6356,11789,11973,15457,18017,32967],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Tail Swing","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Tail Swing","type":4,"radius":10.0,"coneAngleMin":-25,"coneAngleMax":25,"refActorNPCNameID":12200,"refActorRequireCast":true,"refActorCastId":[7222,7919,9550,10325,10348,10812,11451,13461,14002,15338,17029,17203,17242,18110,20326,21500,21584,22367,32279,32647],"refActorComparisonType":6,"includeRotation":true,"AdditionalRotation":3.1415927,"Filled":true}]}
```
```
~Lv2~{"Name":"Rear","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Rear","type":1,"radius":5.5,"color":1677721855,"refActorNPCNameID":12204,"refActorRequireCast":true,"refActorCastId":[3675,5889,6360,8655,10609,11798,12384,14953,15289,15359,21439,24448,24855,27774,32442,33192],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Slowcall","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1107,1106,1108,1124],"ElementsL":[{"Name":"Slowcall","type":4,"radius":6.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12197,"refActorRequireCast":true,"refActorCastId":[924,11777,17525,25988,32635],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Ymir","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Ice Spikes","type":1,"radius":0.0,"color":255,"overlayBGColor":4278190080,"overlayTextColor":4294967295,"overlayVOffset":1.0,"thicc":3.0,"overlayText":"!!! STOP !!!","refActorNPCNameID":12183,"refActorRequireBuff":true,"refActorBuffId":[198,1307,1720,2528],"refActorComparisonType":6},{"Name":"Gelid Charge","type":1,"radius":0.0,"color":255,"overlayVOffset":1.0,"overlayText":"!!! STOP!!!","refActorNPCNameID":12183,"refActorRequireCast":true,"refActorCastId":[1284,8552,33180],"refActorComparisonType":6}]}
```
```
~Lv2~{"Name":"Sprite","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Hypothermal","type":1,"radius":6.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12180,"refActorRequireCast":true,"refActorCastId":[3085,3156,4527,7067,7104,7171,7172,9785,10990,11566,11569,12194,14689,14731,23871,24567,26243,27404,32496],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Grim Fate","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"DCond":5,"ElementsL":[{"Name":"Grim Fate","type":1,"radius":4.5,"color":1677721855,"refActorNPCNameID":12115,"refActorComparisonType":6,"Filled":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":8.0,"MatchIntl":{"En":"readies Grim Fate"}}]}
```
```
~Lv2~{"Name":"Phantom Orthoray","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1124,1108,1107,1106,1105],"ElementsL":[{"Name":"Forearming","type":4,"radius":15.0,"coneAngleMin":-90,"coneAngleMax":90,"refActorNPCNameID":12148,"refActorRequireCast":true,"refActorCastId":[33171],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Atmospheric Displacement","type":1,"radius":10.1,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12148,"refActorRequireCast":true,"refActorCastId":[3966,32436],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Orthotaur","Group":"Deep Dungeon","ZoneLockH":[1100,1099,1101,1102,1103,1104,1124,1108,1107,1106,1105],"ElementsL":[{"Name":"111-Tonze Swing","type":1,"radius":12.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12150,"refActorRequireCast":true,"refActorCastId":[3970,6364,8012,8697,10657,11794,14872,14973,14974,14979,32440],"refActorComparisonType":6,"Filled":true},{"Name":"11-Tonze Swipe","type":4,"radius":12.0,"coneAngleMin":-60,"coneAngleMax":60,"refActorNPCNameID":12150,"refActorRequireCast":true,"refActorCastId":[3969,8014,8699,10658,11793,12444,14972,14978,32439],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Chest Thump","Group":"Deep Dungeon","ZoneLockH":[1104,1099,1100,1101,1102,1103,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Ripe Banana","type":1,"radius":0.0,"thicc":3.0,"refActorNPCNameID":12203,"refActorRequireCast":true,"refActorCastId":[2204,2239,6973,12438,33195,2207,7063,9440,12437,17859,17863,32680],"refActorComparisonType":6,"tether":true},{"Name":"Chest Thump","type":1,"radius":0.1,"Donut":50.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12203,"refActorRequireCast":true,"refActorCastId":[2207,7063,9440,12437,17859,17863,32680],"FillStep":0.3,"refActorComparisonType":6}]}
```
```
~Lv2~{"Name":"Cursed Gaze","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1108,1124,1107,1106,1105],"ElementsL":[{"Name":"Cursed Gaze","type":4,"radius":5.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12155,"refActorRequireCast":true,"refActorCastId":[512,32448],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Particle Collision","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1108,1124,1107,1106,1105],"ElementsL":[{"Name":"Particle Collision","type":1,"radius":6.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12146,"refActorRequireCast":true,"refActorCastId":[3668,4391,32549],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Electric Cachexia","Group":"Deep Dungeon","ZoneLockH":[341,1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Electric Cachexia","type":1,"radius":5.0,"Donut":10.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12193,"refActorRequireCast":true,"refActorCastId":[3889,6235,32979],"FillStep":0.3,"refActorComparisonType":6}]}
```
```
~Lv2~{"Name":"Dread Gaze","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Dread Gaze","type":4,"radius":6.77,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12114,"refActorRequireCast":true,"refActorCastId":[513,13712,14694,15381,18818,29709,32386],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Sneeze","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Sickly Sneeze","type":4,"radius":3.87,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12168,"refActorRequireCast":true,"refActorCastId":[580,2801,11775,31264,32473],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Moldy Sneeze","type":4,"radius":4.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12215,"refActorRequireCast":true,"refActorCastId":[579,1090,2800,5982,12456,21222,21678,32749],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Bloody Puddle","Group":"Deep Dungeon","ZoneLockH":[1102,1099,1100,1101,1103,1104,1124,1108,1107,1106,1105],"ElementsL":[{"Name":"Bloody Puddle","type":1,"radius":12.0,"color":1677721855,"refActorNPCNameID":12162,"refActorRequireCast":true,"refActorCastId":[9812,9813,9814,13443,32460],"refActorComparisonType":6,"Filled":true}]}
```
```
~Lv2~{"Name":"Chimera Voices","Group":"Deep Dungeon","ZoneLockH":[1105,1099,1100,1101,1102,1103,1104,1106,1107,1108,1124],"ElementsL":[{"Name":"Ram's Voice","type":1,"radius":6.8,"color":1677721855,"refActorNPCNameID":12152,"refActorRequireCast":true,"refActorCastId":[1104,1285,2144,2603,3343,7078,11419,12431,13191,13394,14763,15079,16962,21579,31854,32443,32807,32909],"refActorComparisonType":6,"includeHitbox":true,"Filled":true},{"Name":"Dragon's Voice","type":1,"radius":7.5,"Donut":15.0,"color":1677721855,"refActorNPCNameID":12152,"refActorRequireCast":true,"refActorCastId":[1105,1338,1442,2145,2604,3344,7079,10965,11420,12432,13192,13395,14764,15080,16963,21580,31853,32444,32806,32910],"FillStep":0.3,"refActorComparisonType":6}]}
```
```
~Lv2~{"Name":"Scythe Tail","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1124,1108,1107,1106,1105],"ElementsL":[{"Name":"Scythe Tail","type":1,"radius":3.0,"color":1677721855,"refActorNPCNameID":12143,"refActorRequireCast":true,"refActorCastId":[7697,8190,8407,8738,10760,14021,21344,26725,27222,28243,32428,32656],"refActorComparisonType":6,"includeHitbox":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Mean Thrash","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Mean Thrash","type":4,"radius":2.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12127,"refActorRequireCast":true,"refActorCastId":[1279,2781,3345,5209,8005,10689,13982,14944,28031,32403],"refActorComparisonType":6,"includeHitbox":true,"includeRotation":true,"AdditionalRotation":3.1415927,"Filled":true}]}
```
```
~Lv2~{"Name":"Cold Gaze","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1124,1108,1107,1106,1105],"ElementsL":[{"Name":"Cold Gaze","type":4,"radius":12.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12142,"refActorRequireCast":true,"refActorCastId":[498,15455,17973,32427],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Electromagnetism","Group":"Deep Dungeon","ZoneLockH":[1101,1099,1100,1102,1103,1104,1105,1106,1108,1107,1124],"ElementsL":[{"Name":"Electromagnetism","type":1,"radius":14.2,"color":1677721855,"refActorNPCNameID":12133,"refActorRequireCast":true,"refActorCastId":[673,12392,12943,32413],"refActorComparisonType":6,"includeHitbox":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Swinge","Group":"Deep Dungeon","ZoneLockH":[1101,1099,1100,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Swinge","type":4,"radius":30.0,"coneAngleMin":-30,"coneAngleMax":30,"refActorNPCNameID":12138,"refActorRequireCast":true,"refActorCastId":[903,2295,2727,3455,4367,8906,11725,32421,32913],"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Big Burst","Group":"Deep Dungeon","ZoneLockH":[1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1124],"ElementsL":[{"Name":"Big Burst","type":1,"radius":5.1,"color":1677721855,"thicc":3.0,"refActorName":"*","refActorRequireCast":true,"refActorCastId":[1936,5326,5327,5328,5331,5371,5474,5521,5797,6233,9976,10748,13929,21481,23368,27022,29881,30412,30765,30782,31042,31190,31384,32381],"includeHitbox":true,"Filled":true}],"MaxDistance":20.0,"UseDistanceLimit":true,"DistanceLimitType":1}
```
```
~Lv2~{"Name":"Excalibur","Group":"Deep Dungeon","ZoneLockH":[1108,341],"ElementsL":[{"Name":"Solid","type":1,"radius":10.0,"color":1677721855,"refActorNPCNameID":12100,"refActorRequireCast":true,"refActorCastId":[31327],"refActorComparisonType":6,"Filled":true},{"Name":"Empty","type":1,"radius":0.0,"Donut":15.0,"color":1258291400,"refActorNPCNameID":12100,"refActorRequireCast":true,"refActorCastId":[31328],"FillStep":0.1,"refActorComparisonType":6,"includeHitbox":true}]}
```
```
~Lv2~{"Name":"Administrator","Group":"Deep Dungeon","ZoneLockH":[1107],"ElementsL":[{"Name":"Interceptor Alpha","type":4,"radius":30.0,"coneAngleMin":-60,"coneAngleMax":60,"refActorNPCNameID":12103,"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Interceptor Beta","type":3,"Enabled":false,"refY":30.0,"radius":1.0,"color":3372186880,"refActorNPCNameID":12104,"refActorComparisonType":6,"includeRotation":true},{"Name":"Interceptor Gamma","type":1,"Enabled":false,"radius":4.0,"Donut":10.0,"refActorNPCNameID":12105,"refActorComparisonType":6},{"Name":"Cross Lasers 1","type":3,"refY":-15.0,"offY":15.0,"radius":0.0,"refActorNPCNameID":12102,"refActorRequireCast":true,"refActorCastId":[31448],"refActorComparisonType":6,"includeOwnHitbox":true,"includeRotation":true,"LineAddHitboxLengthY":true,"LineAddHitboxLengthYA":true},{"Name":"Cross Lasers 2","type":3,"refY":-15.0,"offY":15.0,"radius":0.0,"refActorNPCNameID":12102,"refActorRequireCast":true,"refActorCastId":[31448],"refActorComparisonType":6,"includeOwnHitbox":true,"includeRotation":true,"AdditionalRotation":1.5707964}]}
```
```
~Lv2~{"Name":"Proto-Kaliya","Group":"Deep Dungeon","ZoneLockH":[1106],"ElementsL":[{"Name":"Rightward Nerve Gas","type":4,"refY":15.0,"radius":30.0,"coneAngleMin":-90,"coneAngleMax":90,"refActorNPCNameID":12247,"refActorRequireCast":true,"refActorCastId":[31425,32935],"FillStep":1.0,"refActorComparisonType":6,"includeRotation":true,"AdditionalRotation":2.3561945,"Filled":true},{"Name":"Leftward Nerve Gas","type":4,"refY":-15.0,"radius":30.0,"coneAngleMin":-90,"coneAngleMax":90,"refActorNPCNameID":12247,"refActorRequireCast":true,"refActorCastId":[31424,32934],"FillStep":1.0,"refActorComparisonType":6,"includeRotation":true,"AdditionalRotation":3.9269907,"Filled":true},{"Name":"Centralized Nerve Gas","type":4,"radius":30.0,"coneAngleMin":-55,"coneAngleMax":55,"refActorNPCNameID":12247,"refActorRequireCast":true,"refActorCastId":[31423,32933],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Nerve Gas Ring","type":1,"Enabled":false,"radius":2.0,"Donut":10.0,"refActorNPCNameID":12247,"refActorRequireCast":true,"refActorCastId":[31426,32930],"refActorComparisonType":6,"includeHitbox":true}]}
```
```
~Lv2~{"Name":"Aeturna Out","Group":"Deep Dungeon","ZoneLockH":[1105],"DCond":5,"ElementsL":[{"Name":"Preternatural Turn Out","type":1,"radius":15.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12246,"refActorComparisonType":6,"onlyTargetable":true,"onlyVisible":true,"Filled":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":6.0,"Match":"(12246>31436)"}]}
```
```
~Lv2~{"Name":"Aeturna In","Group":"Deep Dungeon","ZoneLockH":[1105],"DCond":5,"ElementsL":[{"Name":"Preternatural Turn","type":1,"radius":0.0,"Donut":15.0,"color":1677721855,"refActorNPCNameID":12246,"FillStep":0.3,"refActorComparisonType":6,"includeHitbox":true,"onlyTargetable":true,"onlyVisible":true}],"UseTriggers":true,"Triggers":[{"Type":2,"Duration":6.0,"Match":"(12246>31437)"}]}
```
```
~Lv2~{"Name":"Servomechanical Minotaur 16","Group":"Deep Dungeon","ZoneLockH":[1104],"ElementsL":[{"Name":"Bullish Swipe","type":4,"radius":30.0,"coneAngleMin":-45,"coneAngleMax":45,"refActorNPCNameID":12267,"refActorRequireCast":true,"refActorCastId":[30744,30745,31868,31869,31870,31871,31877,32795],"refActorComparisonType":6,"includeRotation":true,"Filled":true},{"Name":"Bullish Swing","type":1,"radius":7.0,"color":1677721855,"refActorNPCNameID":12267,"refActorRequireCast":true,"refActorCastId":[31875],"refActorComparisonType":6,"includeHitbox":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Servomechanical Chimera 14x","Group":"Deep Dungeon","ZoneLockH":[1103],"ElementsL":[{"Name":"Thunder and Ice In","type":1,"radius":1.0,"Donut":15.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31852],"refActorUseCastTime":true,"refActorCastTimeMax":4.9,"FillStep":0.3,"refActorComparisonType":6,"includeHitbox":true},{"Name":"Thunder and Ice Out","type":1,"radius":3.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31852],"refActorUseCastTime":true,"refActorCastTimeMin":5.0,"refActorCastTimeMax":8.0,"refActorUseOvercast":true,"refActorComparisonType":6,"includeHitbox":true,"Filled":true},{"Name":"Ice and Thunder 1","type":1,"radius":3.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31851],"refActorUseCastTime":true,"refActorCastTimeMax":4.9,"refActorComparisonType":6,"includeHitbox":true,"Filled":true},{"Name":"Ice and Thunder 2","type":1,"radius":1.0,"Donut":15.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31851],"refActorUseCastTime":true,"refActorCastTimeMin":5.0,"refActorCastTimeMax":8.0,"refActorUseOvercast":true,"FillStep":0.3,"refActorComparisonType":6,"includeHitbox":true},{"Name":"Leftbreathed Thunder","type":4,"radius":30.0,"coneAngleMin":-90,"coneAngleMax":90,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31861],"refActorComparisonType":6,"includeRotation":true,"AdditionalRotation":4.712389,"Filled":true},{"Name":"Rightbreathed Cold","type":4,"refX":10.0,"refY":15.0,"radius":30.0,"coneAngleMin":-90,"coneAngleMax":90,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31863],"refActorComparisonType":6,"includeRotation":true,"AdditionalRotation":1.5707964,"Filled":true},{"Name":"Thunderous Cold 1","type":1,"radius":1.0,"Donut":15.0,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31856],"refActorUseCastTime":true,"refActorCastTimeMin":4.0,"refActorCastTimeMax":7.9,"refActorUseOvercast":true,"FillStep":0.3,"refActorComparisonType":6,"includeHitbox":true},{"Name":"Thunderous Cold 2","type":1,"radius":3.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31856],"refActorUseCastTime":true,"refActorCastTimeMin":8.0,"refActorCastTimeMax":12.0,"refActorUseOvercast":true,"refActorComparisonType":6,"includeHitbox":true,"Filled":true},{"Name":"Cold Thunder 1","type":1,"radius":3.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31855],"refActorUseCastTime":true,"refActorCastTimeMin":4.0,"refActorCastTimeMax":7.9,"refActorUseOvercast":true,"refActorComparisonType":6,"includeHitbox":true,"Filled":true},{"Name":"Cold Thunder 2","type":1,"radius":1.0,"Donut":15.0,"color":1677721855,"refActorNPCNameID":12265,"refActorRequireCast":true,"refActorCastId":[31855],"refActorUseCastTime":true,"refActorCastTimeMin":8.0,"refActorCastTimeMax":12.0,"refActorUseOvercast":true,"FillStep":0.3,"refActorComparisonType":6,"includeHitbox":true}]}
```
```
~Lv2~{"Name":"Twintania Clone","Group":"Deep Dungeon","ZoneLockH":[1102],"ElementsL":[{"Name":"Twisting Dive","type":3,"refY":50.0,"radius":1.0,"color":1677721855,"refActorNPCNameID":12263,"refActorRequireCast":true,"refActorCastId":[9906,27531,31471],"refActorComparisonType":6,"includeHitbox":true,"includeRotation":true,"LineAddHitboxLengthYA":true}]}
```
```
~Lv2~{"Name":"Tiamat Clone","Group":"Deep Dungeon","ZoneLockH":[1101,341],"ElementsL":[{"Name":"Dark Wanderer","type":3,"refY":1.0,"radius":0.0,"thicc":2.5,"refActorNPCNameID":12243,"refActorComparisonType":6,"includeHitbox":true,"includeRotation":true,"onlyUnTargetable":true,"Filled":true},{"Name":"Wyrmwing Right","type":3,"Enabled":false,"refX":13.0,"refY":30.0,"offX":13.0,"offY":-10.0,"radius":6.5,"refActorNPCNameID":12242,"refActorRequireCast":true,"refActorCastId":[31845,31846],"refActorComparisonType":6,"includeRotation":true},{"Name":"Wyrmwing Left","type":3,"Enabled":false,"refX":-13.0,"refY":30.0,"offX":-13.0,"offY":-10.0,"radius":6.5,"refActorNPCNameID":12242,"refActorRequireCast":true,"refActorCastId":[31845,31846],"refActorComparisonType":6,"includeRotation":true},{"Name":"Wyrmtail","type":3,"Enabled":false,"refY":30.0,"offY":-10.0,"radius":6.5,"refActorNPCNameID":12242,"refActorRequireCast":true,"refActorCastId":[31843,31844],"refActorComparisonType":6,"includeRotation":true}]}
```
```
~Lv2~{"Name":"Cloning Node","Group":"Deep Dungeon","ZoneLockH":[1100],"ElementsL":[{"Name":"Flame Breath","type":4,"radius":50.0,"coneAngleMin":-15,"coneAngleMax":15,"color":4278190335,"refActorNPCNameID":12262,"refActorRequireCast":true,"refActorCastId":[676,26411,27958,30185,30186,30877,30884,30890,32544,32864],"refActorUseOvercast":true,"FillStep":0.01,"refActorComparisonType":6,"includeRotation":true,"Filled":true}]}
```
```
~Lv2~{"Name":"Gancanagh","Group":"Deep Dungeon","ZoneLockH":[1099],"ElementsL":[{"Name":"Mandrashock","type":1,"radius":10.0,"color":1677721855,"thicc":3.0,"refActorNPCNameID":12241,"refActorRequireCast":true,"refActorCastId":[31478,32700],"refActorComparisonType":6,"Filled":true}]}
```
