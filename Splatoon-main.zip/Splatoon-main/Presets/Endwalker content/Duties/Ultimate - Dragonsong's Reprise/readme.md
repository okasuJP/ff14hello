|Attention! Please do not blindly import all presets. Some presets can repeat what they do in different manner. Please read and decide whether you need something first.|
|---|
# WARNING! You MUST check that your Splatoon version is THE LATEST before importing any triggers.
## Warning! If you will install, update Splatoon or relog while you're in phase 2 of the fight already, Splatoon will not be able to detect that you are in phase 2. In this case specify the phase manually in top right corner of plugin's UI.
