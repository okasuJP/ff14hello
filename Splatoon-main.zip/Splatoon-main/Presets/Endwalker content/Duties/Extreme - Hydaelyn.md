Ground markers for Hydaelyn Ex's Sword attack where you go in intercardinals
```
Hydaelyn~{"ZoneLockH":[996],"DCond":5,"Elements":{"Cross Marks":{"type":3,"refY":10.0,"offY":-10.0,"radius":0.0,"color":1677721855,"refActorType":2,"includeHitbox":true,"includeRotation":true},"Cross Horizontal":{"type":3,"refY":10.0,"offY":-10.0,"radius":0.0,"color":1677721855,"refActorType":2,"includeHitbox":true,"includeRotation":true,"AdditionalRotation":1.5707964}},"UseTriggers":true,"Triggers":[{"Type":2,"Duration":4,"Match":"gains the effect of heros"}]}
```

Circles for sides and back safe areas of Aureloa + Radius for Out-mechanic
```
Hydaelyn 2~{"ZoneLockH":[996],"Elements":{"Out Radius":{"type":1,"refX":101.53556,"refY":116.45032,"radius":10.0,"color":3372154880,"refActorName":"Hydaelyn","onlyTargetable":true},"Boss":{"type":1,"refX":40.52353,"refY":-32.316982,"refZ":-0.00030863285,"offY":5.0,"radius":0.5,"refActorName":"Hydaelyn","includeRotation":true,"onlyTargetable":true},"Bossback":{"type":1,"refX":104.219505,"refY":115.674614,"offY":-5.0,"radius":1.0,"refActorName":"Hydaelyn","includeRotation":true,"onlyTargetable":true},"BossLeft":{"type":1,"refX":468.71915,"refY":-29.575212,"refZ":85.67223,"offX":-5.0,"radius":1.0,"color":3372154880,"refActorName":"Hydaelyn","includeRotation":true,"onlyTargetable":true},"BossRight":{"type":1,"refX":468.71915,"refY":-29.575212,"refZ":85.67223,"offX":5.0,"radius":1.0,"color":3372154886,"refActorName":"Hydaelyn","includeRotation":true,"onlyTargetable":true}},"Triggers":[]}
```
