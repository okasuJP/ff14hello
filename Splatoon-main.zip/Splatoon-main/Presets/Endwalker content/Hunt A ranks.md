Endwalker A ranks, for easier finding
```
A ranks: Labyrinthos~{"ZoneLockH":[956],"Elements":{"Hulder":{"type":1,"refX":-402.39206,"refY":491.77026,"refZ":37.801872,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Hulder","includeHitbox":true,"onlyTargetable":true,"tether":true},"Storsie":{"type":1,"refX":-402.39206,"refY":491.77026,"refZ":37.801872,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Storsie","includeHitbox":true,"onlyTargetable":true,"tether":true}},"Triggers":[]}
```

```
A ranks: Thavnair~{"ZoneLockH":[957],"Elements":{"Sugriva":{"type":1,"refX":35.085453,"refY":201.0979,"refZ":23.756742,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Sugriva","includeHitbox":true,"onlyTargetable":true,"tether":true},"Yilan":{"type":1,"refX":48.340687,"refY":196.49033,"refZ":10.67606,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Yilan","includeHitbox":true,"onlyTargetable":true,"tether":true}},"Triggers":[]}
```

```
A ranks: Garlemald~{"ZoneLockH":[958],"Elements":{"Aegeiros":{"type":1,"refX":48.340687,"refY":196.49033,"refZ":10.67606,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Aegeiros","includeHitbox":true,"onlyTargetable":true,"tether":true},"Minerva":{"type":1,"refX":-253.90291,"refY":-91.01935,"refZ":25.088125,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Minerva","includeHitbox":true,"onlyTargetable":true,"tether":true}},"Triggers":[]}
```

```
A ranks: Mare Lamentorum~{"ZoneLockH":[959],"Elements":{"Mousse Princess":{"type":1,"refX":-428.57486,"refY":481.25247,"refZ":45.137737,"radius":0.35,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Mousse Princess","tether":true},"Lunatender Queen":{"type":1,"refX":37.779205,"refY":157.98601,"refZ":29.999004,"radius":0.35,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Lunatender Queen","tether":true}},"Triggers":[]}
```

```
A ranks: Elpis~{"ZoneLockH":[961],"Elements":{"Petalodus":{"type":1,"refX":-71.620834,"refY":0.72869414,"refZ":18.600334,"radius":0.0,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Petalodus","includeHitbox":true,"onlyTargetable":true,"tether":true},"Gurangatch":{"type":1,"refX":-71.620834,"refY":0.72869414,"refZ":18.600334,"radius":0.0,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Gurangatch","includeHitbox":true,"onlyTargetable":true,"tether":true}},"Triggers":[]}
```

```
A ranks: Ultima Thule~{"ZoneLockH":[960],"Elements":{"Arch-Eta":{"type":1,"refX":-71.620834,"refY":0.72869414,"refZ":18.600334,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Arch-Eta","includeHitbox":true,"onlyTargetable":true,"tether":true},"Fan Ail":{"type":1,"refX":-71.620834,"refY":0.72869414,"refZ":18.600334,"color":3355484415,"overlayTextColor":3355506943,"thicc":3.0,"overlayText":"A rank","refActorName":"Fan Ail","includeHitbox":true,"onlyTargetable":true,"tether":true}},"Triggers":[]}
```
