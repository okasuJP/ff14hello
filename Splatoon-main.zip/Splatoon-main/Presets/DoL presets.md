Auto highlight mining nodes when miner:
```
Mining Nodes~{"ZoneLockH":[],"Elements":{"1":{"type":1,"refX":-423.61624,"refY":404.81842,"refZ":37.41551,"radius":1.0,"refActorName":"Ephemeral Mineral Deposit","includeHitbox":true,"onlyTargetable":true},"2":{"type":1,"refX":-33.29177,"refY":187.68828,"refZ":46.19365,"radius":1.0,"refActorName":"Rocky Outcrop","includeHitbox":true,"onlyTargetable":true},"3":{"type":1,"refX":-41.830532,"refY":642.8633,"refZ":91.52211,"radius":1.0,"refActorName":"Mineral Deposit","includeHitbox":true,"onlyTargetable":true}},"JobLock":65536,"Triggers":[]}
```
Auto highlight botany nodes when botanist
```
Botany Nodes~{"ZoneLockH":[],"Elements":{"1":{"type":1,"refX":-606.2402,"refY":587.7458,"refZ":-26.279226,"radius":1.0,"refActorName":"Ephemeral Lush Vegetation Patch","includeHitbox":true,"onlyTargetable":true},"2":{"type":1,"refX":20.260473,"refY":-486.41888,"refZ":82.827835,"radius":1.0,"refActorName":"Lush Vegetation Patch","includeHitbox":true,"onlyTargetable":true},"3":{"type":1,"refX":-274.63208,"refY":124.43802,"refZ":16.472086,"radius":1.0,"refActorName":"Mature Tree","includeHitbox":true,"onlyTargetable":true}},"JobLock":131072,"Triggers":[]}
```
